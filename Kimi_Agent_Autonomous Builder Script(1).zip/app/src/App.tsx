import { Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect, createContext, useContext, useCallback } from 'react';
import type { AppSettings, AndroidProject, ChatMessage } from '@/types';
import { AnimatePresence } from 'framer-motion';
import Navigation from '@/components/Navigation';
import ParticleBackground from '@/components/ParticleBackground';
import LandingPage from '@/sections/LandingPage';
import BuilderPage from '@/sections/BuilderPage';
import TemplatesPage from '@/sections/TemplatesPage';
import SettingsPage from '@/sections/SettingsPage';
import { DEFAULT_SETTINGS, DEFAULT_TEMPLATES } from '@/types';
import './App.css';

interface AppContextType {
  settings: AppSettings;
  updateSettings: (settings: Partial<AppSettings>) => void;
  projects: AndroidProject[];
  addProject: (project: AndroidProject) => void;
  currentProject: AndroidProject | null;
  setCurrentProject: (project: AndroidProject | null) => void;
  chatHistory: ChatMessage[];
  addChatMessage: (message: Omit<ChatMessage, 'id' | 'timestamp'>) => void;
  templates: typeof DEFAULT_TEMPLATES;
  isNavOpen: boolean;
  setIsNavOpen: (open: boolean) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}

function App() {
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('aapk_settings');
      return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  const [projects, setProjects] = useState<AndroidProject[]>(() => {
    try {
      const saved = localStorage.getItem('aapk_projects');
      return saved ? JSON.parse(saved).map((p: AndroidProject) => ({
        ...p,
        createdAt: new Date(p.createdAt),
      })) : [];
    } catch {
      return [];
    }
  });

  const [currentProject, setCurrentProject] = useState<AndroidProject | null>(null);
  
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('aapk_chat');
      return saved ? JSON.parse(saved).map((m: ChatMessage) => ({
        ...m,
        timestamp: new Date(m.timestamp),
      })) : [];
    } catch {
      return [];
    }
  });

  const [templates] = useState(DEFAULT_TEMPLATES);
  const [isNavOpen, setIsNavOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('aapk_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('aapk_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    if (settings.saveHistory) {
      localStorage.setItem('aapk_chat', JSON.stringify(chatHistory));
    }
  }, [chatHistory, settings.saveHistory]);

  const updateSettings = useCallback((partial: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...partial }));
  }, []);

  const addProject = useCallback((project: AndroidProject) => {
    setProjects(prev => [project, ...prev].slice(0, 50));
    setCurrentProject(project);
  }, []);

  const addChatMessage = useCallback((message: Omit<ChatMessage, 'id' | 'timestamp'>) => {
    const newMessage: ChatMessage = {
      ...message,
      id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5),
      timestamp: new Date(),
    };
    setChatHistory(prev => [...prev, newMessage].slice(-100));
  }, []);

  const contextValue: AppContextType = {
    settings,
    updateSettings,
    projects,
    addProject,
    currentProject,
    setCurrentProject,
    chatHistory,
    addChatMessage,
    templates,
    isNavOpen,
    setIsNavOpen,
  };

  return (
    <AppContext.Provider value={contextValue}>
      <div className="relative min-h-screen bg-background overflow-hidden">
        <ParticleBackground />
        <div className="crt-overlay" />
        
        <Navigation />
        
        <AnimatePresence mode="wait">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/build" element={<BuilderPage />} />
            <Route path="/templates" element={<TemplatesPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </AnimatePresence>
      </div>
    </AppContext.Provider>
  );
}

export default App;
