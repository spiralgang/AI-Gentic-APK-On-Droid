import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  Terminal,
  Cpu,
  Zap,
  Code2,
  Download,
  Sparkles,
  ArrowRight,
  Layers,
  Shield,
  Smartphone,
} from 'lucide-react';
import { useState, useEffect } from 'react';

const terminalLines = [
  { text: '$ aapk init --project FlashlightApp', delay: 0.5, color: 'text-primary' },
  { text: '[INFO] Detecting features...', delay: 1.2, color: 'text-muted-foreground' },
  { text: '[OK] Feature: flashlight', delay: 1.8, color: 'text-accent' },
  { text: '[OK] Permissions: FLASHLIGHT, INTERNET', delay: 2.2, color: 'text-accent' },
  { text: '[INFO] Contacting AI engine...', delay: 2.8, color: 'text-muted-foreground' },
  { text: '[OK] Code generated: 142 lines', delay: 3.5, color: 'text-accent' },
  { text: '[INFO] Building project structure...', delay: 4.0, color: 'text-muted-foreground' },
  { text: '[OK] AndroidManifest.xml', delay: 4.4, color: 'text-accent' },
  { text: '[OK] MainActivity.java', delay: 4.7, color: 'text-accent' },
  { text: '[OK] resources/ (icons, strings, colors)', delay: 5.0, color: 'text-accent' },
  { text: '[SUCCESS] APK ready: FlashlightApp.apk', delay: 5.5, color: 'text-primary font-bold' },
  { text: '$ _', delay: 6.0, color: 'text-primary' },
];

const features = [
  {
    icon: Sparkles,
    title: 'AI Code Generation',
    description: 'Describe your app in natural language and watch AI generate complete Android Java code with proper UI, error handling, and best practices.',
    color: 'from-primary/20 to-primary/5',
    iconColor: 'text-primary',
  },
  {
    icon: Layers,
    title: 'Full Project Structure',
    description: 'Generates AndroidManifest.xml, MainActivity.java, string resources, color themes, and adaptive icons — everything needed for a real APK.',
    color: 'from-accent/20 to-accent/5',
    iconColor: 'text-accent',
  },
  {
    icon: Code2,
    title: 'Syntax Highlighted',
    description: 'Browse generated code with full syntax highlighting for Java and XML. Copy individual files or export the entire project as a ZIP.',
    color: 'from-orange-500/20 to-orange-500/5',
    iconColor: 'text-orange-400',
  },
  {
    icon: Download,
    title: 'Export & Build',
    description: 'Download your project as a ZIP file ready for Android Studio. Auto-detects required permissions based on your app description.',
    color: 'from-purple-500/20 to-purple-500/5',
    iconColor: 'text-purple-400',
  },
  {
    icon: Shield,
    title: 'Permission Detection',
    description: 'Automatically analyzes your description to detect needed permissions — camera, location, storage, bluetooth, and more.',
    color: 'from-red-500/20 to-red-500/5',
    iconColor: 'text-red-400',
  },
  {
    icon: Smartphone,
    title: '12 App Templates',
    description: 'Jump-start with pre-built templates for flashlight, calculator, notes, browser, weather, timer, music player, and more.',
    color: 'from-yellow-500/20 to-yellow-500/5',
    iconColor: 'text-yellow-400',
  },
];

export default function LandingPage() {
  const navigate = useNavigate();
  const [visibleLines, setVisibleLines] = useState<number[]>([]);

  useEffect(() => {
    const timeouts: NodeJS.Timeout[] = [];
    terminalLines.forEach((line, i) => {
      const t = setTimeout(() => {
        setVisibleLines(prev => [...prev, i]);
      }, line.delay * 1000);
      timeouts.push(t);
    });
    return () => timeouts.forEach(clearTimeout);
  }, []);

  return (
    <div className="relative z-10 min-h-screen">
      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center px-4 py-20">
        <div className="max-w-6xl w-full grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="space-y-8"
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30"
            >
              <Cpu className="w-4 h-4 text-primary" />
              <span className="text-xs font-mono text-primary">POWERED BY STEP-3.7-FLASH</span>
            </motion.div>

            {/* Heading */}
            <div className="space-y-4">
              <h1 className="text-5xl lg:text-6xl xl:text-7xl font-black leading-tight">
                <span className="text-foreground">Build Android</span>
                <br />
                <span className="gradient-text-cyan glow-cyan">Apps with AI</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-lg leading-relaxed">
                Describe your app idea in plain English. Our AI engine generates complete Android 
                projects with Java source code, manifests, resources, and permissions — ready to build.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => navigate('/build')}
                className="btn-cyan px-8 py-4 rounded-xl flex items-center gap-3 text-base animate-pulse-glow"
              >
                <Zap className="w-5 h-5" />
                Start Building
                <ArrowRight className="w-4 h-4" />
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => navigate('/templates')}
                className="px-8 py-4 rounded-xl bg-secondary/50 border border-border/50 hover:border-primary/30 text-foreground font-medium transition-all flex items-center gap-3"
              >
                <Layers className="w-5 h-5 text-primary" />
                Browse Templates
              </motion.button>
            </div>

            {/* Stats */}
            <div className="flex gap-8 pt-4">
              {[
                { value: '12+', label: 'Templates' },
                { value: '50+', label: 'Features' },
                { value: '0s', label: 'Setup Time' },
              ].map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 + i * 0.1 }}
                >
                  <div className="text-2xl font-bold text-primary font-mono">{stat.value}</div>
                  <div className="text-xs text-muted-foreground">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right: Terminal Demo */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3, ease: 'easeOut' }}
            className="hidden lg:block"
          >
            <div className="terminal-window glow-border-cyan">
              <div className="terminal-header">
                <div className="terminal-dot red" />
                <div className="terminal-dot yellow" />
                <div className="terminal-dot green" />
                <span className="ml-3 text-xs text-muted-foreground font-mono">aapk-agent — zsh</span>
              </div>
              <div className="terminal-body min-h-[400px]">
                {/* Static prompt */}
                <div className="text-muted-foreground font-mono text-xs mb-4">
                  AI APK Generator v3.0 — Ready to build
                </div>
                
                {terminalLines.map((line, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={visibleLines.includes(i) ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.3 }}
                    className={`font-mono text-xs mb-1 ${line.color}`}
                  >
                    {line.text}
                  </motion.div>
                ))}
                
                {visibleLines.length === terminalLines.length && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="mt-4 p-3 rounded bg-accent/10 border border-accent/30"
                  >
                    <div className="flex items-center gap-2 text-accent text-xs">
                      <Sparkles className="w-3 h-3" />
                      <span>Build complete! Project exported to ~/GeneratedAPKs/</span>
                    </div>
                  </motion.div>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Everything You Need to <span className="gradient-text-cyan">Build Apps</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              From natural language to working Android code in seconds. No Android Studio required.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ y: -4, transition: { duration: 0.2 } }}
                  className={`p-6 rounded-xl bg-gradient-to-br ${feature.color} border border-border/50 hover:border-primary/30 transition-all group`}
                >
                  <div className="w-10 h-10 rounded-lg bg-background/50 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <Icon className={`w-5 h-5 ${feature.iconColor}`} />
                  </div>
                  <h3 className="font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 px-4">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              How It <span className="gradient-text-green">Works</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Three simple steps from idea to Android project
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                title: 'Describe Your App',
                description: 'Tell the AI what you want. "A flashlight app with strobe mode" or "A calculator with dark theme".',
                icon: Terminal,
              },
              {
                step: '02',
                title: 'AI Generates Code',
                description: 'The AI engine analyzes your request, detects features, and writes complete Java Android code.',
                icon: Cpu,
              },
              {
                step: '03',
                title: 'Export & Build',
                description: 'Download your project as a ZIP. Import into Android Studio or build with command-line tools.',
                icon: Download,
              },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.step}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.15 }}
                  className="relative text-center"
                >
                  <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-secondary/50 border border-border/50 flex items-center justify-center relative">
                    <span className="absolute -top-2 -right-2 text-[10px] font-mono text-primary bg-primary/10 px-2 py-0.5 rounded-full border border-primary/30">
                      {item.step}
                    </span>
                    <Icon className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                  
                  {i < 2 && (
                    <div className="hidden md:block absolute top-8 left-[60%] w-[80%]">
                      <ArrowRight className="w-5 h-5 text-muted-foreground/30" />
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Footer */}
      <section className="py-24 px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center p-12 rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border border-primary/30"
        >
          <Sparkles className="w-10 h-10 text-primary mx-auto mb-6" />
          <h2 className="text-3xl font-bold mb-4">Ready to Build Your First App?</h2>
          <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
            No setup required. Just describe your app and let the AI handle the code.
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate('/build')}
            className="btn-cyan px-10 py-4 rounded-xl text-base flex items-center gap-3 mx-auto animate-pulse-glow"
          >
            <Zap className="w-5 h-5" />
            Launch Builder
            <ArrowRight className="w-4 h-4" />
          </motion.button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border/30">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-primary" />
            <span className="text-sm font-mono text-muted-foreground">
              AI APK Generator v3.0
            </span>
          </div>
          <div className="flex items-center gap-6">
            <span className="text-xs text-muted-foreground">Powered by NVIDIA API + Stepfun</span>
            <span className="text-xs text-muted-foreground">Built for Android developers</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
