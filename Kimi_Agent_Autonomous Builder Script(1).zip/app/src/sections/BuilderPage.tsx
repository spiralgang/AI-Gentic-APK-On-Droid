import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Send,
  Download,
  FolderTree,
  FileCode,
  Copy,
  Check,
  Loader2,
  Terminal,
  Sparkles,
  Package,
  Shield,
  Zap,
  AlertCircle,
} from 'lucide-react';
import { useApp } from '@/App';
import type { AndroidProject, ProjectFile, BuildLogEntry } from '@/types';
import {
  generateCodeWithAI,
  generateFallbackCode,
  buildProject,
  exportProjectAsZip,
  downloadBlob,
} from '@/utils/aiGenerator';

function SyntaxHighlighted({ code, language }: { code: string; language: string }) {
  const highlighted = code.split('\n').map((line) => {
    let styled = line;
    
    if (language === 'java') {
      styled = styled.replace(/(\/\/.*$)/, '<span class="syntax-comment">$1</span>');
      styled = styled.replace(/(\/\*[\s\S]*?\*\/)/, '<span class="syntax-comment">$1</span>');
      styled = styled.replace(/("(?:[^"\\]|\\.)*")/g, '<span class="syntax-string">$1</span>');
      styled = styled.replace(/\b(public|private|protected|static|final|void|class|extends|implements|import|package|return|if|else|for|while|try|catch|throw|new|this|super|boolean|int|long|float|double|String|char|byte|short|true|false|null)\b/g, '<span class="syntax-keyword">$1</span>');
      styled = styled.replace(/\b(Activity|LinearLayout|TextView|Button|EditText|WebView|Toast|Intent|Bundle|View|Context|Color|Gravity|CameraManager|FileOutputStream|WebSettings|WebViewClient|Scanner|ByteArrayInputStream|Exception)\b/g, '<span class="syntax-class">$1</span>');
      styled = styled.replace(/\b([a-zA-Z_$][a-zA-Z0-9_$]*)\s*(?=\()/g, '<span class="syntax-function">$1</span>');
      styled = styled.replace(/\b(\d+(?:\.\d+)?)\b/g, '<span class="syntax-number">$1</span>');
      styled = styled.replace(/(@\w+)/g, '<span class="syntax-annotation">$1</span>');
    } else if (language === 'xml') {
      styled = styled.replace(/(&lt;\/?[\w:]+)/g, '<span class="syntax-tag">$1</span>');
      styled = styled.replace(/(<\/?[\w:]+)/g, '<span class="syntax-tag">$1</span>');
      styled = styled.replace(/\b(android:[\w]+)/g, '<span class="syntax-attr">$1</span>');
      styled = styled.replace(/\b(xmlns:[\w]+)/g, '<span class="syntax-attr">$1</span>');
      styled = styled.replace(/("[^"]*")/g, '<span class="syntax-attr-value">$1</span>');
      styled = styled.replace(/(&lt;!--[\s\S]*?--&gt;)/, '<span class="syntax-comment">$1</span>');
    }
    
    return `<div class="line whitespace-pre">${styled || ' '}</div>`;
  }).join('');

  return (
    <div 
      className="line-numbers text-xs leading-5 overflow-x-auto"
      dangerouslySetInnerHTML={{ __html: highlighted }}
    />
  );
}

export default function BuilderPage() {
  const { settings, addProject, addChatMessage } = useApp();
  const [input, setInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [project, setProject] = useState<AndroidProject | null>(null);
  const [activeFile, setActiveFile] = useState<ProjectFile | null>(null);
  const [buildLog, setBuildLog] = useState<BuildLogEntry[]>([]);
  const [copied, setCopied] = useState(false);
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [buildLog]);

  const addLog = (level: BuildLogEntry['level'], message: string) => {
    setBuildLog(prev => [...prev, { timestamp: new Date(), level, message }]);
  };

  const handleGenerate = async () => {
    if (!input.trim() || isGenerating) return;

    const description = input.trim();
    const appName = description.split(' ').slice(0, 3).map(w => w.charAt(0).toUpperCase() + w.slice(1)).join('') + 'App';
    
    setIsGenerating(true);
    setBuildLog([]);
    setProject(null);
    setActiveFile(null);

    addChatMessage({ role: 'user', content: description });
    addLog('info', `Starting generation for: ${appName}`);
    addLog('info', `Description: ${description}`);

    let code = await generateCodeWithAI(description, appName, settings, (entry) => {
      addLog(entry.level, entry.message);
    });
    
    if (!code) {
      addLog('warning', 'AI generation failed, using fallback generator');
      code = generateFallbackCode(appName, `com.ai.generated.${appName.toLowerCase().replace(/[^a-z0-9]/g, '')}`, description);
    }

    addLog('info', 'Building project structure...');
    const newProject = buildProject(appName, description, code);
    
    addLog('success', `Generated ${newProject.files.length} files`);
    addLog('success', `Features: ${newProject.features.join(', ') || 'basic'}`);
    addLog('success', `Permissions: ${newProject.permissions.join(', ')}`);
    addLog('success', 'Project ready!');

    setProject(newProject);
    setActiveFile(newProject.files.find(f => f.path.includes('MainActivity')) || newProject.files[0]);
    addProject(newProject);
    addChatMessage({ role: 'assistant', content: `Generated **${appName}** with ${newProject.files.length} files. Features: ${newProject.features.join(', ') || 'basic'}.` });
    
    setIsGenerating(false);
    setInput('');
  };

  const handleExport = async () => {
    if (!project) return;
    addLog('info', 'Exporting project as ZIP...');
    const blob = await exportProjectAsZip(project);
    downloadBlob(blob, `${project.name}_project.zip`);
    addLog('success', `Downloaded: ${project.name}_project.zip`);
  };

  const handleCopyCode = () => {
    if (!activeFile) return;
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleQuickTemplate = (template: string) => {
    setInput(template);
  };

  const logColor = (level: BuildLogEntry['level']) => {
    switch (level) {
      case 'success': return 'text-accent';
      case 'warning': return 'text-yellow-400';
      case 'error': return 'text-red-400';
      default: return 'text-muted-foreground';
    }
  };

  const fileIcon = (path: string) => {
    if (path.endsWith('.java')) return <FileCode className="w-3.5 h-3.5 text-orange-400" />;
    if (path.endsWith('.xml')) return <FileCode className="w-3.5 h-3.5 text-blue-400" />;
    return <FileCode className="w-3.5 h-3.5 text-muted-foreground" />;
  };

  return (
    <div className="relative z-10 h-screen flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-border/50 bg-card/50 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <Terminal className="w-5 h-5 text-primary" />
          <div>
            <h1 className="font-semibold text-sm">App Builder</h1>
            <p className="text-[10px] text-muted-foreground font-mono">
              {project ? project.name : 'Ready to generate'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {project && (
            <motion.button
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              onClick={handleExport}
              className="btn-green px-4 py-2 rounded-lg text-xs flex items-center gap-2"
            >
              <Download className="w-3.5 h-3.5" />
              Export ZIP
            </motion.button>
          )}
          {isGenerating && (
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
              <Loader2 className="w-3.5 h-3.5 text-yellow-400 animate-spin" />
              <span className="text-xs text-yellow-400 font-mono">Building...</span>
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Left: Chat & Input */}
        <div className="w-[380px] flex flex-col border-r border-border/50 bg-card/30">
          {/* Quick Templates */}
          <div className="p-4 border-b border-border/50">
            <p className="text-[10px] text-muted-foreground font-mono mb-2 uppercase tracking-wider">Quick Start</p>
            <div className="flex flex-wrap gap-1.5">
              {[
                'Flashlight app with toggle',
                'Calculator with dark theme',
                'Notes app with save feature',
                'Simple web browser',
              ].map(template => (
                <button
                  key={template}
                  onClick={() => handleQuickTemplate(template)}
                  className="text-[10px] px-2.5 py-1.5 rounded-md bg-secondary/50 hover:bg-primary/10 hover:text-primary border border-border/30 hover:border-primary/30 transition-all"
                >
                  {template}
                </button>
              ))}
            </div>
          </div>

          {/* Build Log */}
          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {buildLog.length === 0 && !isGenerating && (
              <div className="flex flex-col items-center justify-center h-full text-center space-y-3">
                <Sparkles className="w-8 h-8 text-muted-foreground/30" />
                <div>
                  <p className="text-sm text-muted-foreground">Describe your app to get started</p>
                  <p className="text-[10px] text-muted-foreground/50 mt-1">
                    Example: "A flashlight app with strobe mode"
                  </p>
                </div>
              </div>
            )}
            
            <AnimatePresence>
              {buildLog.map((entry, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-start gap-2 text-xs font-mono"
                >
                  <span className="text-muted-foreground/40 text-[10px] mt-0.5">
                    {entry.timestamp.toLocaleTimeString('en', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                  <span className={logColor(entry.level)}>
                    [{entry.level.toUpperCase()}]
                  </span>
                  <span className="text-foreground/80">{entry.message}</span>
                </motion.div>
              ))}
            </AnimatePresence>
            <div ref={logEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-border/50 bg-card/50">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
                placeholder="Describe your app..."
                disabled={isGenerating}
                className="flex-1 bg-secondary/50 border border-border/50 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 placeholder:text-muted-foreground/40 disabled:opacity-50"
              />
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleGenerate}
                disabled={isGenerating || !input.trim()}
                className="btn-cyan px-4 py-3 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isGenerating ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </motion.button>
            </div>
          </div>
        </div>

        {/* Right: File Tree + Code Viewer */}
        {project ? (
          <div className="flex-1 flex overflow-hidden">
            {/* File Tree */}
            <div className="w-[240px] border-r border-border/50 bg-card/20 overflow-y-auto">
              <div className="p-3 border-b border-border/50 flex items-center justify-between">
                <span className="text-[10px] text-muted-foreground font-mono uppercase tracking-wider flex items-center gap-1.5">
                  <FolderTree className="w-3 h-3" />
                  Project Files
                </span>
                <span className="text-[10px] text-muted-foreground font-mono">{project.files.length}</span>
              </div>
              
              <div className="p-2 space-y-0.5">
                {project.files.map((file) => {
                  const isActive = activeFile?.path === file.path;
                  const parts = file.path.split('/');
                  const depth = parts.length - 1;
                  
                  return (
                    <button
                      key={file.path}
                      onClick={() => setActiveFile(file)}
                      className={`w-full text-left file-tree-item text-xs ${
                        isActive ? 'active' : ''
                      }`}
                      style={{ paddingLeft: `${12 + depth * 12}px` }}
                    >
                      {fileIcon(file.path)}
                      <span className={isActive ? 'text-primary font-medium' : 'text-foreground/70'}>
                        {parts[parts.length - 1]}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Info Panel */}
              <div className="p-3 border-t border-border/50 space-y-3">
                <div>
                  <p className="text-[10px] text-muted-foreground font-mono mb-1 flex items-center gap-1">
                    <Package className="w-2.5 h-2.5" /> Package
                  </p>
                  <p className="text-[10px] text-foreground/70 font-mono truncate">{project.packageName}</p>
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground font-mono mb-1 flex items-center gap-1">
                    <Shield className="w-2.5 h-2.5" /> Permissions
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {project.permissions.map(p => (
                      <span key={p} className="text-[9px] px-1.5 py-0.5 rounded bg-primary/10 text-primary font-mono">
                        {p}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground font-mono mb-1 flex items-center gap-1">
                    <Zap className="w-2.5 h-2.5" /> Features
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {project.features.map(f => (
                      <span key={f} className="text-[9px] px-1.5 py-0.5 rounded bg-accent/10 text-accent font-mono">
                        {f}
                      </span>
                    )) || <span className="text-[9px] text-muted-foreground">basic</span>}
                  </div>
                </div>
              </div>
            </div>

            {/* Code Viewer */}
            <div className="flex-1 flex flex-col overflow-hidden">
              {activeFile && (
                <>
                  {/* Code Header */}
                  <div className="flex items-center justify-between px-4 py-3 border-b border-border/50 bg-card/30">
                    <div className="flex items-center gap-2">
                      {fileIcon(activeFile.path)}
                      <span className="text-xs font-mono">{activeFile.path}</span>
                      <span className="text-[10px] text-muted-foreground font-mono">
                        ({activeFile.content.length} chars)
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleCopyCode}
                        className="p-1.5 rounded hover:bg-secondary/50 transition-colors"
                        title="Copy code"
                      >
                        {copied ? (
                          <Check className="w-3.5 h-3.5 text-accent" />
                        ) : (
                          <Copy className="w-3.5 h-3.5 text-muted-foreground" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Code Content */}
                  <div className="flex-1 overflow-auto p-4 bg-[#0a0a0f]">
                    <SyntaxHighlighted 
                      code={activeFile.content} 
                      language={activeFile.language} 
                    />
                  </div>
                </>
              )}
            </div>
          </div>
        ) : (
          /* Empty State */
          <div className="flex-1 flex items-center justify-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center space-y-4"
            >
              <div className="w-20 h-20 mx-auto rounded-2xl bg-primary/5 border border-primary/20 flex items-center justify-center">
                <Sparkles className="w-8 h-8 text-primary/40" />
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-1">No Project Generated Yet</h3>
                <p className="text-sm text-muted-foreground max-w-sm">
                  Enter a description in the chat panel to generate your first Android app. 
                  The AI will create the complete project structure.
                </p>
              </div>
              {!settings.apiKey && (
                <div className="flex items-center gap-2 px-4 py-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30 max-w-sm mx-auto">
                  <AlertCircle className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                  <p className="text-xs text-yellow-400 text-left">
                    API key not configured. Add your NVIDIA API key in Settings for AI-powered generation, or use the fallback generator.
                  </p>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
}
