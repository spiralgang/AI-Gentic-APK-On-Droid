import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Settings,
  Key,
  Thermometer,
  Hash,
  Save,
  RotateCcw,
  Check,
  AlertCircle,
  Database,
  Trash2,
  ExternalLink,
  Cpu,
  Globe,
  ToggleLeft,
  ToggleRight,
} from 'lucide-react';
import { useApp } from '@/App';
import { DEFAULT_SETTINGS } from '@/types';

export default function SettingsPage() {
  const { settings, updateSettings, projects, chatHistory } = useApp();
  const [saved, setSaved] = useState(false);
  const [formState, setFormState] = useState({ ...settings });

  const handleSave = () => {
    updateSettings(formState);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleReset = () => {
    setFormState({ ...DEFAULT_SETTINGS });
  };

  const handleClearProjects = () => {
    if (window.confirm('Are you sure you want to clear all project history?')) {
      localStorage.removeItem('aapk_projects');
      window.location.reload();
    }
  };

  const handleClearChat = () => {
    if (window.confirm('Are you sure you want to clear chat history?')) {
      localStorage.removeItem('aapk_chat');
      window.location.reload();
    }
  };

  const handleClearAll = () => {
    if (window.confirm('WARNING: This will reset ALL data including settings, projects, and chat history. Are you sure?')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  const inputClass = "w-full px-4 py-2.5 bg-secondary/50 border border-border/50 rounded-lg text-sm focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 placeholder:text-muted-foreground/40";
  const labelClass = "text-sm font-medium mb-1.5 block flex items-center gap-2";
  const descClass = "text-[11px] text-muted-foreground mt-1";

  return (
    <div className="relative z-10 min-h-screen p-6 lg:p-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center">
              <Settings className="w-4 h-4 text-primary" />
            </div>
            <h1 className="text-2xl font-bold">Settings</h1>
          </div>
          <p className="text-sm text-muted-foreground">
            Configure your AI engine, generation preferences, and manage data
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-6"
        >
          {/* API Configuration */}
          <div className="p-6 rounded-xl bg-card/50 border border-border/50">
            <div className="flex items-center gap-2 mb-6">
              <Key className="w-4 h-4 text-primary" />
              <h2 className="font-semibold">API Configuration</h2>
            </div>

            <div className="space-y-5">
              <div>
                <label className={labelClass}>
                  <Key className="w-3.5 h-3.5" /> NVIDIA API Key
                </label>
                <input
                  type="password"
                  value={formState.apiKey}
                  onChange={(e) => setFormState(prev => ({ ...prev, apiKey: e.target.value }))}
                  placeholder="nvapi-..."
                  className={inputClass}
                />
                <p className={descClass}>
                  Your NVIDIA API key for accessing the AI model. Get one at{' '}
                  <a 
                    href="https://build.nvidia.com/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary hover:underline inline-flex items-center gap-0.5"
                  >
                    build.nvidia.com <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                </p>
                {!formState.apiKey && (
                  <div className="mt-2 flex items-center gap-2 px-3 py-2 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
                    <AlertCircle className="w-3.5 h-3.5 text-yellow-400 flex-shrink-0" />
                    <p className="text-[11px] text-yellow-400">
                      Without an API key, the app will use fallback code generation (less advanced)
                    </p>
                  </div>
                )}
              </div>

              <div>
                <label className={labelClass}>
                  <Globe className="w-3.5 h-3.5" /> API Endpoint URL
                </label>
                <input
                  type="text"
                  value={formState.apiUrl}
                  onChange={(e) => setFormState(prev => ({ ...prev, apiUrl: e.target.value }))}
                  className={inputClass}
                />
                <p className={descClass}>The NVIDIA API endpoint for chat completions</p>
              </div>

              <div>
                <label className={labelClass}>
                  <Cpu className="w-3.5 h-3.5" /> AI Model
                </label>
                <input
                  type="text"
                  value={formState.model}
                  onChange={(e) => setFormState(prev => ({ ...prev, model: e.target.value }))}
                  className={inputClass}
                />
                <p className={descClass}>Default: stepfun-ai/step-3.7-flash</p>
              </div>
            </div>
          </div>

          {/* Generation Settings */}
          <div className="p-6 rounded-xl bg-card/50 border border-border/50">
            <div className="flex items-center gap-2 mb-6">
              <Cpu className="w-4 h-4 text-accent" />
              <h2 className="font-semibold">Generation Settings</h2>
            </div>

            <div className="space-y-5">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className={labelClass}>
                    <Thermometer className="w-3.5 h-3.5" /> Temperature
                  </label>
                  <span className="text-xs font-mono text-primary bg-primary/10 px-2 py-0.5 rounded">
                    {formState.temperature}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={formState.temperature}
                  onChange={(e) => setFormState(prev => ({ ...prev, temperature: parseFloat(e.target.value) }))}
                  className="w-full accent-primary"
                />
                <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                  <span>Precise (0)</span>
                  <span>Balanced (0.5)</span>
                  <span>Creative (1)</span>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className={labelClass}>
                    <Hash className="w-3.5 h-3.5" /> Max Tokens
                  </label>
                  <span className="text-xs font-mono text-primary bg-primary/10 px-2 py-0.5 rounded">
                    {formState.maxTokens}
                  </span>
                </div>
                <input
                  type="range"
                  min="512"
                  max="8192"
                  step="512"
                  value={formState.maxTokens}
                  onChange={(e) => setFormState(prev => ({ ...prev, maxTokens: parseInt(e.target.value) }))}
                  className="w-full accent-primary"
                />
                <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                  <span>512</span>
                  <span>4096</span>
                  <span>8192</span>
                </div>
              </div>
            </div>
          </div>

          {/* Preferences */}
          <div className="p-6 rounded-xl bg-card/50 border border-border/50">
            <div className="flex items-center gap-2 mb-6">
              <ToggleLeft className="w-4 h-4 text-orange-400" />
              <h2 className="font-semibold">Preferences</h2>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Save Chat History</p>
                  <p className="text-[11px] text-muted-foreground">Store chat conversations in localStorage</p>
                </div>
                <button
                  onClick={() => setFormState(prev => ({ ...prev, saveHistory: !prev.saveHistory }))}
                  className="relative"
                >
                  {formState.saveHistory ? (
                    <ToggleRight className="w-8 h-8 text-primary" />
                  ) : (
                    <ToggleLeft className="w-8 h-8 text-muted-foreground" />
                  )}
                </button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Auto-Build on Generate</p>
                  <p className="text-[11px] text-muted-foreground">Automatically build project after AI generation</p>
                </div>
                <button
                  onClick={() => setFormState(prev => ({ ...prev, autoBuild: !prev.autoBuild }))}
                  className="relative"
                >
                  {formState.autoBuild ? (
                    <ToggleRight className="w-8 h-8 text-primary" />
                  ) : (
                    <ToggleLeft className="w-8 h-8 text-muted-foreground" />
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Data Management */}
          <div className="p-6 rounded-xl bg-card/50 border border-border/50">
            <div className="flex items-center gap-2 mb-6">
              <Database className="w-4 h-4 text-red-400" />
              <h2 className="font-semibold">Data Management</h2>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                <div>
                  <p className="text-sm">Clear Project History</p>
                  <p className="text-[11px] text-muted-foreground">
                    {projects.length} projects stored
                  </p>
                </div>
                <button
                  onClick={handleClearProjects}
                  className="px-3 py-1.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors text-xs flex items-center gap-1.5"
                >
                  <Trash2 className="w-3 h-3" />
                  Clear
                </button>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                <div>
                  <p className="text-sm">Clear Chat History</p>
                  <p className="text-[11px] text-muted-foreground">
                    {chatHistory.length} messages stored
                  </p>
                </div>
                <button
                  onClick={handleClearChat}
                  className="px-3 py-1.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors text-xs flex items-center gap-1.5"
                >
                  <Trash2 className="w-3 h-3" />
                  Clear
                </button>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg bg-red-500/5 border border-red-500/20">
                <div>
                  <p className="text-sm font-medium text-red-400">Reset Everything</p>
                  <p className="text-[11px] text-muted-foreground">
                    Clear all data including settings
                  </p>
                </div>
                <button
                  onClick={handleClearAll}
                  className="px-3 py-1.5 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors text-xs flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3 h-3" />
                  Reset All
                </button>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex gap-3">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleSave}
              className="flex-1 btn-cyan py-3 rounded-xl text-sm flex items-center justify-center gap-2"
            >
              {saved ? (
                <>
                  <Check className="w-4 h-4" />
                  Saved!
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  Save Settings
                </>
              )}
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleReset}
              className="px-6 py-3 rounded-xl bg-secondary/50 border border-border/50 hover:border-primary/30 text-foreground text-sm flex items-center gap-2 transition-all"
            >
              <RotateCcw className="w-4 h-4" />
              Reset
            </motion.button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
