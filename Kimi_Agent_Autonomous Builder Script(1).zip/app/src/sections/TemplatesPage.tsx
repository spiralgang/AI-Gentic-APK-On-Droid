import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  Search,
  Zap,
  ArrowRight,
  X,
  Sparkles,
  Tag,
  Package,
  Shield,
  Loader2,
} from 'lucide-react';
import { useApp } from '@/App';
import type { Template, BuildLogEntry } from '@/types';
import {
  generateCodeWithAI,
  generateFallbackCode,
  buildProject,
} from '@/utils/aiGenerator';

const categories = ['All', 'Utility', 'Productivity', 'Internet', 'Information', 'Media', 'Finance', 'Games', 'Security'];

export default function TemplatesPage() {
  const navigate = useNavigate();
  const { settings, templates, addProject, addChatMessage } = useApp();
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatingId, setGeneratingId] = useState<string | null>(null);

  const filteredTemplates = templates.filter(t => {
    const matchesSearch = search === '' || 
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.description.toLowerCase().includes(search.toLowerCase()) ||
      t.tags.some(tag => tag.toLowerCase().includes(search.toLowerCase()));
    const matchesCategory = activeCategory === 'All' || t.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const handleGenerateFromTemplate = async (template: Template) => {
    if (isGenerating) return;
    
    setIsGenerating(true);
    setGeneratingId(template.id);

    const dummyLog = (_level: BuildLogEntry['level'], _message: string) => {};

    let code = await generateCodeWithAI(template.prompt, template.defaultName, settings, (entry) => {
      dummyLog(entry.level, entry.message);
    });
    
    if (!code) {
      code = generateFallbackCode(template.defaultName, template.defaultPackage, template.prompt);
    }

    const project = buildProject(template.defaultName, template.prompt, code);
    addProject(project);
    addChatMessage({ 
      role: 'assistant', 
      content: `Generated **${template.defaultName}** from template "${template.name}". ${project.files.length} files created.` 
    });

    setIsGenerating(false);
    setGeneratingId(null);
    setSelectedTemplate(null);
    navigate('/build');
  };

  const handlePreviewTemplate = (template: Template) => {
    setSelectedTemplate(template);
  };

  const categoryColors: { [key: string]: string } = {
    Utility: 'text-yellow-400 bg-yellow-400/10 border-yellow-400/30',
    Productivity: 'text-blue-400 bg-blue-400/10 border-blue-400/30',
    Internet: 'text-cyan-400 bg-cyan-400/10 border-cyan-400/30',
    Information: 'text-purple-400 bg-purple-400/10 border-purple-400/30',
    Media: 'text-pink-400 bg-pink-400/10 border-pink-400/30',
    Finance: 'text-green-400 bg-green-400/10 border-green-400/30',
    Games: 'text-orange-400 bg-orange-400/10 border-orange-400/30',
    Security: 'text-red-400 bg-red-400/10 border-red-400/30',
  };

  return (
    <div className="relative z-10 min-h-screen p-6 lg:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center">
              <Zap className="w-4 h-4 text-primary" />
            </div>
            <h1 className="text-2xl font-bold">App Templates</h1>
          </div>
          <p className="text-sm text-muted-foreground">
            Choose from {templates.length} pre-built templates to jump-start your app
          </p>
        </motion.div>

        {/* Search & Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8 space-y-4"
        >
          {/* Search */}
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search templates..."
              className="w-full pl-10 pr-4 py-2.5 bg-secondary/50 border border-border/50 rounded-lg text-sm focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 placeholder:text-muted-foreground/40"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2"
              >
                <X className="w-3.5 h-3.5 text-muted-foreground hover:text-foreground" />
              </button>
            )}
          </div>

          {/* Categories */}
          <div className="flex flex-wrap gap-2">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  activeCategory === cat
                    ? 'bg-primary text-black'
                    : 'bg-secondary/50 text-muted-foreground hover:text-foreground hover:bg-secondary'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Templates Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence mode="popLayout">
            {filteredTemplates.map((template, i) => (
              <motion.div
                key={template.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ delay: i * 0.05 }}
                whileHover={{ y: -4 }}
                className="group p-5 rounded-xl bg-card/50 border border-border/50 hover:border-primary/30 transition-all cursor-pointer"
                onClick={() => handlePreviewTemplate(template)}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-primary" />
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${categoryColors[template.category] || 'text-muted-foreground bg-muted border-border'}`}>
                    {template.category}
                  </span>
                </div>

                <h3 className="font-semibold mb-1 group-hover:text-primary transition-colors">
                  {template.name}
                </h3>
                <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                  {template.description}
                </p>

                <div className="flex flex-wrap gap-1 mb-4">
                  {template.tags.slice(0, 3).map(tag => (
                    <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded bg-secondary text-muted-foreground font-mono">
                      {tag}
                    </span>
                  ))}
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleGenerateFromTemplate(template);
                  }}
                  disabled={isGenerating}
                  className="w-full btn-cyan py-2 rounded-lg text-xs flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {generatingId === template.id ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Zap className="w-3.5 h-3.5" />
                      Generate App
                    </>
                  )}
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredTemplates.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <Search className="w-8 h-8 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">No templates match your search</p>
          </motion.div>
        )}
      </div>

      {/* Template Preview Modal */}
      <AnimatePresence>
        {selectedTemplate && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedTemplate(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-card border border-border/50 rounded-xl max-w-lg w-full overflow-hidden"
            >
              {/* Modal Header */}
              <div className="p-6 border-b border-border/50">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
                      <Sparkles className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold">{selectedTemplate.name}</h2>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${categoryColors[selectedTemplate.category]}`}>
                        {selectedTemplate.category}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => setSelectedTemplate(null)}
                    className="p-1.5 rounded-lg hover:bg-secondary transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Modal Body */}
              <div className="p-6 space-y-4">
                <p className="text-sm text-muted-foreground">
                  {selectedTemplate.description}
                </p>

                <div>
                  <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-wider mb-2 flex items-center gap-1">
                    <Tag className="w-3 h-3" /> Tags
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedTemplate.tags.map(tag => (
                      <span key={tag} className="text-xs px-2 py-1 rounded bg-secondary text-foreground/70 font-mono">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-secondary/30 border border-border/30">
                    <p className="text-[10px] text-muted-foreground font-mono mb-1 flex items-center gap-1">
                      <Package className="w-3 h-3" /> Default Name
                    </p>
                    <p className="text-xs font-mono">{selectedTemplate.defaultName}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-secondary/30 border border-border/30">
                    <p className="text-[10px] text-muted-foreground font-mono mb-1 flex items-center gap-1">
                      <Shield className="w-3 h-3" /> Package
                    </p>
                    <p className="text-xs font-mono truncate">{selectedTemplate.defaultPackage}</p>
                  </div>
                </div>

                <div>
                  <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-wider mb-2">
                    AI Prompt
                  </p>
                  <div className="p-3 rounded-lg bg-[#0a0a0f] border border-border/30 text-xs text-muted-foreground font-mono leading-relaxed">
                    {selectedTemplate.prompt}
                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="p-6 border-t border-border/50 flex gap-3">
                <button
                  onClick={() => handleGenerateFromTemplate(selectedTemplate)}
                  disabled={isGenerating}
                  className="flex-1 btn-cyan py-3 rounded-xl text-sm flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4" />
                      Generate This App
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
