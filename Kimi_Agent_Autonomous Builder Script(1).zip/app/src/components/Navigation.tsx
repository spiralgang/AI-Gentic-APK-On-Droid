import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import {
  Terminal,
  Hammer,
  LayoutGrid,
  Settings,
  Menu,
  X,
  Cpu,
  ChevronRight,
} from 'lucide-react';

const navItems = [
  { path: '/', label: 'Home', icon: Terminal, description: 'Dashboard' },
  { path: '/build', label: 'Builder', icon: Hammer, description: 'Generate Apps' },
  { path: '/templates', label: 'Templates', icon: LayoutGrid, description: '12 Presets' },
  { path: '/settings', label: 'Settings', icon: Settings, description: 'Configure' },
];

export default function Navigation() {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Mobile Menu Toggle */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed top-4 left-4 z-50 lg:hidden p-2 rounded-lg bg-card/80 backdrop-blur-md border border-border/50 hover:border-primary/50 transition-all"
      >
        {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </button>

      {/* Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar Navigation */}
      <motion.aside
        initial={false}
        animate={{
          x: isOpen ? 0 : -280,
        }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="fixed left-0 top-0 bottom-0 w-[260px] bg-card/95 backdrop-blur-xl border-r border-border/50 z-40 flex flex-col lg:translate-x-0"
      >
        {/* Logo */}
        <div className="p-6 border-b border-border/50">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="relative w-10 h-10 flex items-center justify-center">
              <div className="absolute inset-0 bg-gradient-to-br from-primary to-accent rounded-lg opacity-20 group-hover:opacity-30 transition-opacity" />
              <div className="absolute inset-0 border border-primary/40 rounded-lg group-hover:border-primary/60 transition-colors" />
              <Cpu className="w-5 h-5 text-primary relative z-10" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-sm tracking-wide gradient-text-cyan">AI APK GEN</span>
              <span className="text-[10px] text-muted-foreground font-mono">v3.0.0</span>
            </div>
          </Link>
        </div>

        {/* Nav Items */}
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;

            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsOpen(false)}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all group relative ${
                  isActive
                    ? 'bg-primary/10 border border-primary/30'
                    : 'hover:bg-secondary/50 border border-transparent'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeNav"
                    className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-6 bg-primary rounded-r-full"
                    transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                  />
                )}
                <Icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-primary' : 'text-muted-foreground group-hover:text-foreground'
                  }`}
                />
                <div className="flex flex-col flex-1">
                  <span
                    className={`text-sm font-medium ${
                      isActive ? 'text-primary' : 'text-foreground/80'
                    }`}
                  >
                    {item.label}
                  </span>
                  <span className="text-[10px] text-muted-foreground">{item.description}</span>
                </div>
                {isActive && (
                  <ChevronRight className="w-3 h-3 text-primary" />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Status Footer */}
        <div className="p-4 border-t border-border/50">
          <div className="flex items-center gap-3 px-4 py-2 rounded-lg bg-secondary/30">
            <div className="relative">
              <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
              <div className="absolute inset-0 w-2 h-2 rounded-full bg-accent animate-ping opacity-50" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] text-muted-foreground font-mono">ENGINE STATUS</span>
              <span className="text-xs text-accent font-medium">Ready</span>
            </div>
          </div>
        </div>
      </motion.aside>

      {/* Desktop Spacer */}
      <div className="hidden lg:block w-[260px] flex-shrink-0" />
    </>
  );
}
