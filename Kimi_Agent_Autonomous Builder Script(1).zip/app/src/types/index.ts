export interface ProjectFile {
  path: string;
  content: string;
  language: string;
}

export interface AndroidProject {
  id: string;
  name: string;
  packageName: string;
  description: string;
  files: ProjectFile[];
  manifest: string;
  mainActivity: string;
  features: string[];
  permissions: string[];
  createdAt: Date;
  buildStatus: 'idle' | 'generating' | 'building' | 'success' | 'error';
  buildLog: string[];
}

export interface Template {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: string;
  defaultName: string;
  defaultPackage: string;
  prompt: string;
  tags: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
}

export interface AppSettings {
  apiKey: string;
  apiUrl: string;
  model: string;
  temperature: number;
  maxTokens: number;
  theme: 'dark' | 'darker';
  autoBuild: boolean;
  saveHistory: boolean;
}

export interface BuildLogEntry {
  timestamp: Date;
  level: 'info' | 'success' | 'warning' | 'error';
  message: string;
}

export interface FeatureDetection {
  name: string;
  keywords: string[];
  permissions: string[];
}

export const DEFAULT_SETTINGS: AppSettings = {
  apiKey: '',
  apiUrl: 'https://integrate.api.nvidia.com/v1/chat/completions',
  model: 'stepfun-ai/step-3.7-flash',
  temperature: 0.2,
  maxTokens: 4096,
  theme: 'dark',
  autoBuild: true,
  saveHistory: true,
};

export const FEATURE_MAP: FeatureDetection[] = [
  { name: 'flashlight', keywords: ['flashlight', 'torch', 'light'], permissions: ['FLASHLIGHT'] },
  { name: 'camera', keywords: ['camera', 'photo', 'picture', 'scan'], permissions: ['CAMERA'] },
  { name: 'calculator', keywords: ['calculator', 'calc', 'math', 'compute'], permissions: [] },
  { name: 'notes', keywords: ['notes', 'notepad', 'memo', 'text editor'], permissions: [] },
  { name: 'browser', keywords: ['browser', 'web', 'internet', 'url'], permissions: ['INTERNET'] },
  { name: 'location', keywords: ['location', 'gps', 'map', 'position'], permissions: ['ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION'] },
  { name: 'audio', keywords: ['audio', 'music', 'sound', 'player', 'record'], permissions: ['RECORD_AUDIO'] },
  { name: 'storage', keywords: ['storage', 'file', 'save', 'download'], permissions: ['READ_EXTERNAL_STORAGE', 'WRITE_EXTERNAL_STORAGE'] },
  { name: 'bluetooth', keywords: ['bluetooth', 'ble', 'wireless'], permissions: ['BLUETOOTH', 'BLUETOOTH_ADMIN'] },
  { name: 'wifi', keywords: ['wifi', 'network', 'connection'], permissions: ['ACCESS_WIFI_STATE', 'CHANGE_WIFI_STATE'] },
  { name: 'vibrate', keywords: ['vibrate', 'vibration', 'haptic'], permissions: ['VIBRATE'] },
  { name: 'contacts', keywords: ['contacts', 'phonebook', 'address book'], permissions: ['READ_CONTACTS'] },
  { name: 'sms', keywords: ['sms', 'message', 'texting'], permissions: ['SEND_SMS', 'READ_SMS'] },
  { name: 'call', keywords: ['call', 'dial', 'phone'], permissions: ['CALL_PHONE'] },
  { name: 'nfc', keywords: ['nfc', 'near field'], permissions: ['NFC'] },
  { name: 'fingerprint', keywords: ['fingerprint', 'biometric', 'auth'], permissions: ['USE_BIOMETRIC'] },
];

export const DEFAULT_TEMPLATES: Template[] = [
  {
    id: 'flashlight',
    name: 'Flashlight',
    description: 'A simple flashlight app with torch toggle and strobe mode',
    icon: 'Zap',
    category: 'Utility',
    defaultName: 'FlashlightApp',
    defaultPackage: 'com.ai.flashlight',
    prompt: 'Create a flashlight app with a toggle button to turn the camera flash on/off. Include a strobe mode with adjustable frequency slider. Show a bright torch icon that glows when active.',
    tags: ['utility', 'hardware', 'camera'],
  },
  {
    id: 'calculator',
    name: 'Calculator',
    description: 'Full-featured calculator with basic and scientific operations',
    icon: 'Calculator',
    category: 'Productivity',
    defaultName: 'SmartCalculator',
    defaultPackage: 'com.ai.calculator',
    prompt: 'Create a calculator app with a clean modern UI. Support basic operations (+, -, *, /), decimal numbers, clear function, and calculation history display. Use a dark theme with cyan accent colors.',
    tags: ['productivity', 'math', 'tool'],
  },
  {
    id: 'notes',
    name: 'Notes App',
    description: 'Note-taking app with create, edit, delete, and search',
    icon: 'StickyNote',
    category: 'Productivity',
    defaultName: 'QuickNotes',
    defaultPackage: 'com.ai.notes',
    prompt: 'Create a notes app where users can add, edit, delete, and search notes. Each note should have a title and content. Store notes in localStorage. Use a card-based layout with dark theme.',
    tags: ['productivity', 'storage', 'editor'],
  },
  {
    id: 'browser',
    name: 'Web Browser',
    description: 'Minimal web browser with address bar and navigation',
    icon: 'Globe',
    category: 'Internet',
    defaultName: 'MiniBrowser',
    defaultPackage: 'com.ai.browser',
    prompt: 'Create a web browser app with URL input field, back/forward navigation buttons, refresh, and a web view area. Show loading progress. Include bookmarks feature using localStorage.',
    tags: ['internet', 'web', 'connectivity'],
  },
  {
    id: 'weather',
    name: 'Weather App',
    description: 'Weather display with current conditions and forecast',
    icon: 'CloudSun',
    category: 'Information',
    defaultName: 'WeatherView',
    defaultPackage: 'com.ai.weather',
    prompt: 'Create a weather app UI showing current temperature, conditions (sunny/cloudy/rainy), humidity, wind speed. Include a 5-day forecast section with weather icons. Use a gradient background based on weather condition.',
    tags: ['information', 'weather', 'ui'],
  },
  {
    id: 'timer',
    name: 'Timer & Stopwatch',
    description: 'Countdown timer and stopwatch with lap times',
    icon: 'Timer',
    category: 'Utility',
    defaultName: 'TimerStopwatch',
    defaultPackage: 'com.ai.timer',
    prompt: 'Create a timer and stopwatch app with two tabs. Timer: set hours/minutes/seconds, countdown display with large numbers, alarm when complete. Stopwatch: start/stop/reset, lap times table.',
    tags: ['utility', 'time', 'tool'],
  },
  {
    id: 'music',
    name: 'Music Player',
    description: 'Local music player with playlist and controls',
    icon: 'Music',
    category: 'Media',
    defaultName: 'MusicPlayer',
    defaultPackage: 'com.ai.music',
    prompt: 'Create a music player app with play/pause, next/previous track buttons, progress bar, album art placeholder, playlist view, and volume control. Use a sleek dark UI with visualizer effect.',
    tags: ['media', 'audio', 'entertainment'],
  },
  {
    id: 'todo',
    name: 'Todo List',
    description: 'Task manager with categories, priorities, and due dates',
    icon: 'CheckSquare',
    category: 'Productivity',
    defaultName: 'TaskManager',
    defaultPackage: 'com.ai.todo',
    prompt: 'Create a todo list app with add task, mark complete, delete, and filter (all/active/completed). Support categories (Work, Personal, Shopping), priority levels with color coding, and due dates.',
    tags: ['productivity', 'organization', 'tool'],
  },
  {
    id: 'expense',
    name: 'Expense Tracker',
    description: 'Track expenses with categories and monthly summary',
    icon: 'Wallet',
    category: 'Finance',
    defaultName: 'ExpenseTracker',
    defaultPackage: 'com.ai.expense',
    prompt: 'Create an expense tracker app to add expenses with amount, category (Food, Transport, Entertainment, Bills), and date. Show total spending, category breakdown with a pie chart using CSS, and monthly summary.',
    tags: ['finance', 'tracking', 'tool'],
  },
  {
    id: 'quiz',
    name: 'Quiz Game',
    description: 'Trivia quiz with multiple categories and scoring',
    icon: 'Brain',
    category: 'Games',
    defaultName: 'TriviaQuiz',
    defaultPackage: 'com.ai.quiz',
    prompt: 'Create a quiz game app with multiple categories (Science, History, Tech, General Knowledge), multiple choice questions, score tracking, timer per question, and results screen with correct/incorrect summary.',
    tags: ['games', 'education', 'trivia'],
  },
  {
    id: 'converter',
    name: 'Unit Converter',
    description: 'Convert between various units of measurement',
    icon: 'ArrowLeftRight',
    category: 'Utility',
    defaultName: 'UnitConverter',
    defaultPackage: 'com.ai.converter',
    prompt: 'Create a unit converter app supporting Length (m, km, ft, mi), Weight (kg, g, lb, oz), Temperature (C, F, K), and Volume. Include a swap button, clear input, and history of recent conversions.',
    tags: ['utility', 'tool', 'conversion'],
  },
  {
    id: 'password',
    name: 'Password Generator',
    description: 'Generate secure passwords with customizable options',
    icon: 'Shield',
    category: 'Security',
    defaultName: 'PassGen',
    defaultPackage: 'com.ai.password',
    prompt: 'Create a password generator app with options for length (8-32), include uppercase, lowercase, numbers, symbols. Show password strength indicator, copy to clipboard button, and password history.',
    tags: ['security', 'tool', 'generator'],
  },
];

export const SYSTEM_PROMPT = `You are an expert Android developer and automated code generation engine.
Your task is to generate a complete, working Android application based on the user's description.

Output Requirements:
1. Generate a complete MainActivity.java file that extends Activity
2. Create UI programmatically (no XML layouts needed)
3. Use only standard Android SDK APIs
4. Include all necessary imports
5. Handle basic error cases with try-catch
6. Add JavaDoc comments for key methods
7. Use modern Android patterns where applicable
8. Return ONLY the Java code, no markdown formatting, no explanations outside code comments

The activity should:
- Use LinearLayout or RelativeLayout for the UI
- Have proper dark theme styling with Color.parseColor()
- Include interactive elements (buttons, inputs, etc.)
- Handle screen rotation with configChanges
- Show Toast messages for user feedback
- Follow Android best practices`;
