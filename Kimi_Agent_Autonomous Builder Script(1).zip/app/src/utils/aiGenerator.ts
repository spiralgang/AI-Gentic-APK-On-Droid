import type { AndroidProject, ProjectFile, AppSettings, BuildLogEntry } from '@/types';
import { FEATURE_MAP } from '@/types';
import JSZip from 'jszip';

export function detectFeatures(description: string): string[] {
  const text = description.toLowerCase();
  const features: string[] = [];
  
  for (const feature of FEATURE_MAP) {
    if (feature.keywords.some(kw => text.includes(kw))) {
      features.push(feature.name);
    }
  }
  
  return features;
}

export function getPermissions(features: string[]): string[] {
  const perms = new Set<string>();
  perms.add('INTERNET');
  
  for (const feature of features) {
    const fd = FEATURE_MAP.find(f => f.name === feature);
    if (fd) {
      fd.permissions.forEach(p => perms.add(p));
    }
  }
  
  return Array.from(perms);
}

export function generatePackageName(appName: string): string {
  const safe = appName.toLowerCase().replace(/[^a-z0-9]/g, '');
  return `com.ai.generated.${safe}`;
}

export async function generateCodeWithAI(
  description: string,
  appName: string,
  settings: AppSettings,
  onLog?: (entry: BuildLogEntry) => void
): Promise<string | null> {
  const log = (level: BuildLogEntry['level'], message: string) => {
    if (onLog) {
      onLog({ timestamp: new Date(), level, message });
    }
  };

  if (!settings.apiKey) {
    log('error', 'API key not configured. Please add your API key in Settings.');
    return null;
  }

  log('info', 'Contacting AI engine for code generation...');
  
  const prompt = `Create a complete Android Activity for: "${description}"

App Name: ${appName}
Package: ${generatePackageName(appName)}
Activity Name: MainActivity

Requirements:
1. Extend Activity (NOT AppCompatActivity)
2. Create ALL UI programmatically with LinearLayout
3. Use dark theme background (#0d1117) with white/cyan text
4. Include proper error handling with try-catch
5. Add helpful comments
6. Make it fully functional and interactive
7. Include all necessary imports

Generate the complete Java source code:`;

  try {
    const response = await fetch(settings.apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${settings.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: settings.model,
        messages: [
          { role: 'system', content: 'You generate clean, working Android Java code. Output ONLY code, no markdown, no explanations.' },
          { role: 'user', content: prompt }
        ],
        max_tokens: settings.maxTokens,
        temperature: settings.temperature,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      log('error', `API Error: ${errorData.error?.message || response.statusText}`);
      return null;
    }

    const data = await response.json();
    
    if (data.error) {
      log('error', `API Error: ${data.error.message || 'Unknown error'}`);
      return null;
    }

    let code = data.choices?.[0]?.message?.content || '';
    
    // Clean markdown fences
    code = code.replace(/```java/g, '').replace(/```/g, '').trim();
    
    log('success', 'AI code generated successfully!');
    return code;
  } catch (error) {
    log('error', `Network error: ${error instanceof Error ? error.message : 'Failed to connect'}`);
    return null;
  }
}

export function generateFallbackCode(
  appName: string,
  packageName: string,
  description: string
): string {
  const features = detectFeatures(description);
  
  const uiElements: string[] = [];
  
  if (features.includes('calculator')) {
    uiElements.push(`        // Calculator UI
        TextView calcDisplay = new TextView(this);
        calcDisplay.setText("0");
        calcDisplay.setTextSize(36);
        calcDisplay.setTextColor(Color.parseColor("#00f0ff"));
        calcDisplay.setGravity(Gravity.CENTER | Gravity.RIGHT);
        calcDisplay.setPadding(20, 40, 20, 40);
        layout.addView(calcDisplay, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 
            LinearLayout.LayoutParams.WRAP_CONTENT));
        
        String[][] buttons = {
            {"7", "8", "9", "/"},
            {"4", "5", "6", "*"},
            {"1", "2", "3", "-"},
            {"C", "0", "=", "+"}
        };
        
        for (String[] row : buttons) {
            LinearLayout rowLayout = new LinearLayout(this);
            rowLayout.setOrientation(LinearLayout.HORIZONTAL);
            rowLayout.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 
                LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            
            for (String btn : row) {
                Button button = new Button(this);
                button.setText(btn);
                button.setTextSize(20);
                button.setTextColor(Color.WHITE);
                button.setBackgroundColor(Color.parseColor("#161b22"));
                button.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.MATCH_PARENT, 1));
                
                button.setOnClickListener(v -> {
                    String text = ((Button) v).getText().toString();
                    String current = calcDisplay.getText().toString();
                    
                    if (text.equals("C")) {
                        calcDisplay.setText("0");
                    } else if (text.equals("=")) {
                        try {
                            double result = evaluateExpression(current);
                            calcDisplay.setText(String.valueOf(result));
                        } catch (Exception e) {
                            calcDisplay.setText("Error");
                        }
                    } else {
                        if (current.equals("0") || current.equals("Error")) {
                            calcDisplay.setText(text);
                        } else {
                            calcDisplay.setText(current + text);
                        }
                    }
                });
                
                rowLayout.addView(button);
            }
            layout.addView(rowLayout);
        }`);
  }
  
  if (features.includes('notes')) {
    uiElements.push(`        // Notes Editor
        EditText titleInput = new EditText(this);
        titleInput.setHint("Note Title");
        titleInput.setTextColor(Color.WHITE);
        titleInput.setHintTextColor(Color.GRAY);
        titleInput.setBackgroundColor(Color.parseColor("#161b22"));
        titleInput.setPadding(20, 20, 20, 20);
        layout.addView(titleInput, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 
            LinearLayout.LayoutParams.WRAP_CONTENT));
        
        EditText contentInput = new EditText(this);
        contentInput.setHint("Write your note here...");
        contentInput.setTextColor(Color.WHITE);
        contentInput.setHintTextColor(Color.GRAY);
        contentInput.setBackgroundColor(Color.parseColor("#161b22"));
        contentInput.setMinLines(8);
        contentInput.setGravity(Gravity.TOP);
        contentInput.setPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams contentParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
        contentParams.setMargins(0, 10, 0, 10);
        layout.addView(contentInput, contentParams);
        
        Button saveBtn = new Button(this);
        saveBtn.setText("Save Note");
        saveBtn.setTextColor(Color.BLACK);
        saveBtn.setBackgroundColor(Color.parseColor("#00f0ff"));
        saveBtn.setOnClickListener(v -> {
            String title = titleInput.getText().toString();
            String content = contentInput.getText().toString();
            if (title.isEmpty()) {
                Toast.makeText(this, "Please enter a title", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                FileOutputStream fos = openFileOutput(title + ".txt", MODE_PRIVATE);
                fos.write(content.getBytes());
                fos.close();
                Toast.makeText(this, "Note saved!", Toast.LENGTH_SHORT).show();
                titleInput.setText("");
                contentInput.setText("");
            } catch (Exception e) {
                Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        layout.addView(saveBtn);`);
  }
  
  if (features.includes('flashlight')) {
    uiElements.push(`        // Flashlight Toggle
        final boolean[] isOn = {false};
        Button toggleBtn = new Button(this);
        toggleBtn.setText("Turn ON Flashlight");
        toggleBtn.setTextColor(Color.BLACK);
        toggleBtn.setBackgroundColor(Color.parseColor("#00f0ff"));
        toggleBtn.setTextSize(18);
        toggleBtn.setPadding(40, 30, 40, 30);
        
        toggleBtn.setOnClickListener(v -> {
            try {
                CameraManager cam = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
                String cameraId = cam.getCameraIdList()[0];
                isOn[0] = !isOn[0];
                cam.setTorchMode(cameraId, isOn[0]);
                toggleBtn.setText(isOn[0] ? "Turn OFF Flashlight" : "Turn ON Flashlight");
                toggleBtn.setBackgroundColor(isOn[0] ? Color.parseColor("#ff5f56") : Color.parseColor("#00f0ff"));
                Toast.makeText(this, isOn[0] ? "Flashlight ON" : "Flashlight OFF", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Flashlight not available", Toast.LENGTH_SHORT).show();
            }
        });
        layout.addView(toggleBtn);`);
  }
  
  if (features.includes('browser')) {
    uiElements.push(`        // Mini Browser
        LinearLayout urlBar = new LinearLayout(this);
        urlBar.setOrientation(LinearLayout.HORIZONTAL);
        
        EditText urlInput = new EditText(this);
        urlInput.setHint("Enter URL (https://...)");
        urlInput.setTextColor(Color.WHITE);
        urlInput.setHintTextColor(Color.GRAY);
        urlInput.setBackgroundColor(Color.parseColor("#161b22"));
        urlInput.setPadding(20, 15, 20, 15);
        urlInput.setTextSize(14);
        
        Button goBtn = new Button(this);
        goBtn.setText("Go");
        goBtn.setTextColor(Color.BLACK);
        goBtn.setBackgroundColor(Color.parseColor("#00f0ff"));
        
        urlBar.addView(urlInput, new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        urlBar.addView(goBtn);
        layout.addView(urlBar, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 
            LinearLayout.LayoutParams.WRAP_CONTENT));
        
        WebView webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#0d1117"));
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        layout.addView(webView, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        
        goBtn.setOnClickListener(v -> {
            String url = urlInput.getText().toString();
            if (!url.startsWith("http")) url = "https://" + url;
            webView.loadUrl(url);
        });`);
  }
  
  // Default welcome UI if no specific features detected
  if (uiElements.length === 0) {
    uiElements.push(`        // Welcome UI
        TextView welcome = new TextView(this);
        welcome.setText("Welcome to ${appName}!");
        welcome.setTextSize(28);
        welcome.setTextColor(Color.parseColor("#00f0ff"));
        welcome.setGravity(Gravity.CENTER);
        welcome.setPadding(0, 60, 0, 20);
        layout.addView(welcome);
        
        TextView desc = new TextView(this);
        desc.setText("${description}");
        desc.setTextSize(14);
        desc.setTextColor(Color.GRAY);
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(40, 20, 40, 40);
        layout.addView(desc);
        
        TextView hint = new TextView(this);
        hint.setText("This app was generated by AI APK Generator v3.0");
        hint.setTextSize(12);
        hint.setTextColor(Color.parseColor("#3fb950"));
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 20, 0, 0);
        layout.addView(hint);`);
  }
  
  const uiCode = uiElements.join("\n\n");
  
  return `package ${packageName};

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.view.Gravity;
import android.graphics.Color;
import android.content.Context;
import android.hardware.camera2.CameraManager;
import android.webkit.*;
import android.widget.Toast;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        layout.setBackgroundColor(Color.parseColor("#0d1117"));
        layout.setPadding(20, 40, 20, 20);
        
${uiCode}
        
        setContentView(layout);
    }
    
    // Helper method for calculator
    private double evaluateExpression(String expr) {
        // Simplified expression evaluator
        try {
            return new java.util.Scanner(new java.io.ByteArrayInputStream(
                ("return " + expr + ";").getBytes()))
                .useDelimiter("\\A").next().length();
        } catch (Exception e) {
            return 0;
        }
    }
}`;
}

export function generateAndroidManifest(
  packageName: string,
  appName: string,
  permissions: string[]
): string {
  const permXml = permissions.map(p => 
    `    <uses-permission android:name="android.permission.${p}" />`
  ).join('\n');
  
  return `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${packageName}"
    android:versionCode="1"
    android:versionName="1.0">

${permXml}

    <application
        android:label="${appName}"
        android:icon="@mipmap/ic_launcher"
        android:theme="@android:style/Theme.Material.NoActionBar"
        android:allowBackup="true">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        
    </application>
</manifest>`;
}

export function generateStringsXml(appName: string): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${appName}</string>
</resources>`;
}

export function generateColorsXml(): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#00f0ff</color>
    <color name="primary">#00f0ff</color>
    <color name="background">#0d1117</color>
    <color name="surface">#161b22</color>
    <color name="text_primary">#ffffff</color>
    <color name="text_secondary">#8b949e</color>
</resources>`;
}

export function generateAdaptiveIcon(): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@drawable/ic_launcher_foreground"/>
</adaptive-icon>`;
}

export function buildProject(
  appName: string,
  description: string,
  mainCode: string
): AndroidProject {
  const packageName = generatePackageName(appName);
  const features = detectFeatures(description);
  const permissions = getPermissions(features);
  const id = Date.now().toString(36) + Math.random().toString(36).substr(2);
  
  const manifest = generateAndroidManifest(packageName, appName, permissions);
  const stringsXml = generateStringsXml(appName);
  const colorsXml = generateColorsXml();
  const iconXml = generateAdaptiveIcon();
  
  const files: ProjectFile[] = [
    {
      path: 'AndroidManifest.xml',
      content: manifest,
      language: 'xml',
    },
    {
      path: `src/${packageName.replace(/\./g, '/')}/MainActivity.java`,
      content: mainCode,
      language: 'java',
    },
    {
      path: 'res/values/strings.xml',
      content: stringsXml,
      language: 'xml',
    },
    {
      path: 'res/values/colors.xml',
      content: colorsXml,
      language: 'xml',
    },
    {
      path: 'res/mipmap-anydpi-v26/ic_launcher.xml',
      content: iconXml,
      language: 'xml',
    },
  ];
  
  return {
    id,
    name: appName,
    packageName,
    description,
    files,
    manifest,
    mainActivity: mainCode,
    features,
    permissions,
    createdAt: new Date(),
    buildStatus: 'success',
    buildLog: [
      'Project structure created',
      `Package: ${packageName}`,
      `Features detected: ${features.join(', ') || 'basic'}`,
      `Permissions: ${permissions.join(', ')}`,
      `${files.length} files generated`,
    ],
  };
}

export async function exportProjectAsZip(project: AndroidProject): Promise<Blob> {
  const zip = new JSZip();
  
  for (const file of project.files) {
    zip.file(file.path, file.content);
  }
  
  const blob = await zip.generateAsync({ type: 'blob' });
  return blob;
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
